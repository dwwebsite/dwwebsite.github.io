// IS496: Computer Networks (Spring 2022)
// Programming Assignment 1 -  Starter Code 
// Name and Netid of each member:
// Member 1: 
// Member 2: 
// Member 3: 



// Note: 
// This starter code is optional. Feel free to develop your own solution to Part 1. 
// The finished code for Part 1 can also be used for Part 2 of this assignment. 



// Include any necessary libraries below

#include <iostream>
#include <cstdio>
#include <stdlib.h>
#include <cstring>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "pg1lib.h"



using namespace std;

// ############# Beginning of Part 1 ##############
// TODO: define a buffer size for the message to be read from the UDP socket
#define BUFFER 

int part1(){
	printf("********** PART 1 **********\n");
	
	// define any necessary socket variables here
	int sock;
	
	// TODO: fill in the IP address of the host and the port number
	int port = 

	// TODO: create a socket
	if ( ) {
		perror("Error creating socket!");
		return 1;
	}
	bzero( );
	sin.sin_family =
	sin.sin_addr.s_addr = 
	sin.sin_port = 


	// TODO: bind sockt descriptor with the socket address
	if ( ) {
		perror("Binding socket failed!");
		return 1;
	}


	printf("Waiting ...\n");
	
// 	TODO: receive message from the client and record the address of the client socket




//  TODO: convert the message from byte to string and print it to the screen



//  TODO: 
//     1. convert the acknowledgement (e.g., interger of 1) from host byte order to network byte order
//     2. send the converted acknowledgement to the client




//  TODO: close the socket


	return 0;
}




// ############# End of Part 1 ##############




// ############# Beginning of Part 2 ##############
// Note: any functions/variables for Part 2 will go here 

int part2(char *argv[]) {
	printf("********** PART 2 **********\n");
	
	return 0;
}

// ############## End of Part 2 ##############


int main(int argc, char*argv[]) {
 // Your program will go with function part1() if there is no command line input. 
 // Otherwise, it will go with function part2() to handle the command line input 
 // as specified in the assignment instruction. 
	if (argc==1) {
		part1();
	}
	else{
		part2(argv);
	}
	return 0;
}
