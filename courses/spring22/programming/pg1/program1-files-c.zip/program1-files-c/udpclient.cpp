// IS496: Computer Networks (Spring 2022)
// Programming Assignment 1 -  Starter Code
// Name and Netid of each member:
// Member 1: 
// Member 2: 
// Member 3: 


// Note: 
// This starter code is optional. Feel free to develop your own solution to Part 1. 
// The finished code for Part 1 can also be used for Part 2 of this assignment. 


// Include any necessary libraries below

#include <iostream>
#include <sstream>
#include <cstdio>
#include <stdlib.h>
#include <cstring>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "pg1lib.h"

using namespace std;

// ############# Beginning of Part 1 ##############
// TODO: define a buffer size for the message to be read from the UDP socket
#define BUFFER

int part1(){
	printf("********** PART 1 **********\n");

	// define any necessary socket variables here
	int sock;
	struct hostent *hp;
	struct sockaddr_in sin;
	socklen_t addr_len = sizeof(sin);


	// TODO: fill in the hostname and port number 
	char host[] = 
	int port = 

	// A dummy message to test the code
	char text[] = "Hello World";


	// TODO: convert the host name to the corresponding IP address
	hp = 
	if(!hp){
		cout << "Unknown host: " << host << endl;
		return 1;
	}

	// TODO: create a datagram socket
	bzero( );
	sin.sin_family = 
	sin.sin_port =  
	bcopy( );

	if ( ) {
		perror("Error creating socket \n");
		return 1;
	}

 // TODO: convert the message from string to byte and send it to the server




 // TODO: 
 //    1. receive the acknowledgement from the server 
 //    2. convert it from network byte order to host byte order 




 // TODO: print the acknowledgement to the screen




 // TODO: close the socket
	

	return 0;
}



// ############# End of Part 1 ##############




// ############# Beginning of Part 2 ##############
// Note: any functions/variables for Part 2 will go here 

int part2 (char *argv[]){
	printf("********** PART 2 **********\n");

	
	return 0;
}
// ############## End of Part 2 ##############




int main(int argc, char*argv[]) {
// Your program will go with function part1() if there is no command line input. 
// Otherwise, it will go with function part2() to handle the command line input 
// as specified in the assignment instruction. 

	if (argc==1){
		part1();
	}
	else{
		part2(argv);
	}
	return 0;
}
